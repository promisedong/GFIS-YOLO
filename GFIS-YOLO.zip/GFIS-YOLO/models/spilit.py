import os
import shutil
 
train_txt = r"D:\目标检测代码\datasets\m2cai16-tool-locations\ImageSets\Main\train.txt"
test_txt = r"D:\目标检测代码\datasets\m2cai16-tool-locations\ImageSets\Main\test.txt"
val_txt = r"D:\目标检测代码\datasets\m2cai16-tool-locations\ImageSets\Main\val.txt"
trainval_txt = r"D:\目标检测代码\datasets\m2cai16-tool-locations\ImageSets\Main\trainval.txt"
 
img_folder = r"D:\目标检测代码\datasets\m2cai16-tool-locations\JPEGImages"
yolo_folder = r"D:\目标检测代码\datasets\m2cai16-tool-locations\Annotations_yolo"
 
HRSID_dir = r"D:\目标检测代码\datasets\m2cai16-tool-locations\yolo_format"
 
file_train =  open(train_txt)
file_test = open(test_txt)
file_val = open(val_txt)
file_trainval = open(trainval_txt)

for line in file_train.readlines():
    line = line.strip()
    shutil.copyfile(os.path.join(img_folder,line + ".jpg"),os.path.join(HRSID_dir,"images","train",line + ".jpg")) #根据train.txt指示的文件名将对应的图片复制到yolo格式整理的数据文件夹中
    shutil.copyfile(os.path.join(yolo_folder,line + ".txt"),os.path.join(HRSID_dir,"labels","train",line + ".txt")) #根据train.txt指示的文件名将对应的标注文件复制到yolo格式整理的数据文件夹中
 
for line in file_test.readlines():
    line = line.strip()
    shutil.copyfile(os.path.join(img_folder, line + ".jpg"),os.path.join(HRSID_dir, "images", "test",line + ".jpg"))  # 根据train.txt指示的文件名将对应的图片复制到yolo格式整理的数据文件夹中
    shutil.copyfile(os.path.join(yolo_folder, line + ".txt"),os.path.join(HRSID_dir, "labels", "test",line + ".txt"))  # 根据train.txt指示的文件名将对应的标注文件复制到yolo格式整理的数据文件夹中

for line in file_val.readlines():
    line = line.strip()
    shutil.copyfile(os.path.join(img_folder,line + ".jpg"),os.path.join(HRSID_dir,"images","val",line + ".jpg")) #根据train.txt指示的文件名将对应的图片复制到yolo格式整理的数据文件夹中
    shutil.copyfile(os.path.join(yolo_folder,line + ".txt"),os.path.join(HRSID_dir,"labels","val",line + ".txt")) #根据train.txt指示的文件名将对应的标注文件复制到yolo格式整理的数据文件夹中

for line in file_trainval.readlines():
    line = line.strip()
    shutil.copyfile(os.path.join(img_folder,line + ".jpg"),os.path.join(HRSID_dir,"images","trainval",line + ".jpg")) 
    shutil.copyfile(os.path.join(yolo_folder,line + ".txt"),os.path.join(HRSID_dir,"labels","trainval",line + ".txt")) 